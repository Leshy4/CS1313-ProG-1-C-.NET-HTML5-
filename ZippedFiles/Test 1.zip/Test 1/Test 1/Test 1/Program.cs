﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test1
{
    class Program
    {
        static void Main(string[] args)
        {
            int F, S, T;
            int Ans;

            //allows the text to change which number you want
            F = getNumbers("First");
            S = getNumbers("Second");
            T = getNumbers("Third");



            //sending information to different methods
            Ans = calculateAnswers(F, S, T);
            calculateAnswers(F, S, T);
            displayAnswer(F, S, T, Ans);

        }


        //collects 3 numbers that are typed, First,  Second,  and Third and returns it to the main
        static int getNumbers(string num)
        {
            Console.WriteLine("Please Enter Your {0} Number", num);
            return int.Parse(Console.ReadLine());
        }

        //Takes the First, Second, and Third number and multiplies them together and sends the information to the main.
        static int calculateAnswers(int First, int Second, int Third)
        {
            int Answer;

            Answer = First * Second * Third;
            string Answer1 = Answer.ToString();
            return int.Parse(Answer1);


        }


        //Collects all the variables and displays them on the screen, along with answer of multiplying them together.
        static void displayAnswer(int fN, int sN, int tN, int Ans)
        {
            Console.WriteLine("When You Multiply the numbers");
            Console.WriteLine("{0} and {1} and {2}", fN, sN, tN);
            Console.WriteLine("Your answer will be {0}", Ans);
        }

    }
}
