﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//right click References, add Reference, System.Windows.Form = using MessageBox(s)

namespace Chpt6
{
    class Program
    {
        static void Main(string[] args)
        {   //int loopnumber = 1;
            //while (loopnumber < 10)
            //{   displayOut(loopnumber);
            //    loopnumber++;           
            //}
            
            Random mynum = new Random();
            string myMessage= "";
            int small = 1000;
            int large = 1000;
            for (int loopnumber = 1; loopnumber < 10; loopnumber+=2)
            {   
                double y = Math.Pow(loopnumber, 2);
                
                int r = mynum.Next(1, 1000);
                if (small > r)
                {
                    small = r;
                }
                if (large < r)
                {
                    large = r;
                }
                //get the range working

                myMessage += "your line number is " + loopnumber + " the number square is " + y +" Random Dice Number " + r + "\n";

                int StrengthLevel= 35;
                int WeaponStat = 50;
                double StrAttribute = StrengthLevel * 0.15;
                double StrTotal = (StrengthLevel + WeaponStat);
                double Damage = r + StrTotal;
                Console.WriteLine("Your Damage =" + Damage);
            }
            displayOut(myMessage);
        }
        static void displayOut(string x)
        {
            MessageBox.Show(x, "My Box", MessageBoxButtons.YesNoCancel,MessageBoxIcon.Warning);    
            //MessageBox.Show("your line number is " + x +" the number square is " + y);
            //Console.WriteLine("your line number is {0}", x);
            //Console.WriteLine("the number square is {0}", y);
        }
    
    
    
    
    }
    





}
