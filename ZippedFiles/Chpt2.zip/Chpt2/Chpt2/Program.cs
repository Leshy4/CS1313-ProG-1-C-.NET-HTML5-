﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chpt2
{
    class Program
    {
        static void Main(string[] args)
        {
            //const string makes a class, unchangeable
            //string makes a class, changeable
            //int makes a variable, all capitals

            string CAR="Chevy";
            int tankSize = 12;
            int milesDriven = 300; 

            //CAR = CAR + " Impala";
            //don't have to specify if defined

            CAR += " Impala";

            //double = int but can have decimals

            double mPG;
            mPG = milesDriven / tankSize;

            // {0} is a placeholder for the first variable outside of quotes
            // {1} is the next placeholder for the next variable
            // \n = next line, \t = tab

            Console.WriteLine("My car is an " + CAR + " it's tank will hold {0} gallons, \nI drove {1} miles.",tankSize, milesDriven);
            Console.WriteLine("I get {0} miles per gallon", mPG); 





            Console.Read();
            


        }
    }
}
