﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final
{
    class Program
    {
        static void Main(string[] args)
        {   int score = 0;            
            Console.WriteLine("Your Score = " + score);
            int spin = wheelSpin();
            Console.WriteLine("Your Wheel Spin = " + wheelSpin());
            string sWord =  SecretWord();           
            
            string disWord = "";

            guessLetter(sWord);
            disWord = DashWord(sWord, score);
            FinalDisplay(sWord, disWord);
        }

        public static void IntroDisplay(int num)
        {            
            Console.WriteLine("This Is My Text");
            //INTRODUCTION SCREEN
            for (int j = 0; j < 10; j++)
            {
                for (int n = 0; n < 4; n++)
                {
                    IntroDisplay(n);
                    //this shows you Display for 1 second
                    System.Threading.Thread.Sleep(1000);
                }
            }
            string[] colorSet = { "Red", "Yellow", "Blue", "Green" };

            Console.ForegroundColor = (ConsoleColor)Enum.Parse(typeof(ConsoleColor), colorSet[num]);
            Console.BackgroundColor = ConsoleColor.Blue;
            

            // \r = Replace
            Console.Write("\r Wheel Of Fortune!!!! Starting in 4 Seconds: {0}", num);
            switch (num)
            {
                case 0: Console.Write("/"); break;
                case 1: Console.Write("-"); break;
                case 2: Console.Write("\\"); break;
                case 3: Console.Write("|"); break;
            }
            return;
        }

            public static string DashWord(string sWord, int score)
        {
            string myDashes="";
            int points = wheelSpin();
            //char myGuesses = guessLetter();
            string myGuesses="";

            char[] secret = sWord.ToCharArray();            
            char guess = guessLetter(""); // this would let the user guess a letter
            myGuesses += guess;                
            
            
               for (int i = 0; i < sWord.Length; i++)
               {
                   if (secret[i] == guess)
                   {
                       score += points;
                       myDashes += guess;
                   }
                   else
                   {
                       myDashes += " _ ";
                   }               
               }
             return myDashes + score;
        }

            public static string SecretWord()
            {
                Console.WriteLine("Enter Your Secret Word");
                string word = Console.ReadLine();
                return word.ToUpper();                
            }

            public static char guessLetter(string secretWord)
            {                  
                    Console.WriteLine("Guess Your Letter");
                    return char.Parse(Console.ReadLine().ToUpper());              
            }        

        public static int wheelSpin()
        {
            int spinPoints=0;
            int[] wheel = {0,100,200,300,400,500,600,700,800,900,1000};
            Random rn = new Random();
            int x = rn.Next(0, 11);

            spinPoints += wheel[x];

            if(wheel[x]==0)
            {
                Console.WriteLine("Bankrupt");
                spinPoints = 0;
            }
            else
            {  spinPoints += wheel[x];  }

            return spinPoints;
        }
         

        public static void FinalDisplay(string sWord, string disWord)
        {
            Console.WriteLine("Your Secret Word Is {0} \nYour Dash Word Is {1}", sWord,disWord);
        }


    }
}
