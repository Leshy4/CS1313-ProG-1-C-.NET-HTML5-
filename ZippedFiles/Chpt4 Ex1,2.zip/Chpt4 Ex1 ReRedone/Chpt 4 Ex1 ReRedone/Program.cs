﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_4_Ex_1
{
    class Program
    {
        static void Main(string[] args)
        {

            double yearlySalary = 120345;

            Employees E1 = new Employees("Jebidiyah Gann ", "DATE OF HIRE: 01/01/1998", 3250, "Work Number: 101101", yearlySalary);


            Console.WriteLine(E1.name);
            Console.WriteLine(E1.dateOfHire);
            Console.WriteLine(E1.monthlySalary);
            Console.WriteLine(E1.number);


            Console.WriteLine(E1.ToString());



        }


    }
}
