﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_4_Ex_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int Quanity=qGetter();
            double Cost=Calculation(Quanity);

            Invoice E1 = new Invoice(305052, "$5.00", "Gallon of Milk");
            
            Console.WriteLine(E1.itemNumber);
            Console.WriteLine(E1.Price);
            Console.WriteLine(E1.Description);
           
            Console.WriteLine(E1.ToString());


            Calculation(Quanity);
            
            Displayer(Cost);

           
        }

        public static int qGetter()
        { Console.WriteLine("How Many Gallons of Milk Would You Like?");
          return int.Parse(Console.ReadLine());         
        }

        public static double Calculation(double quanity)
        {   double Cost;
            Cost = quanity*5;
            return Cost;
        }

        public static void Displayer(double cost)
        { Console.WriteLine("This Costs -  ${0}", cost); }

        
    
   }
        
}
