﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chpt5_Ex6
{
    class Program
    {
        static void Main(string[] args)
        {   int shape;
            
            Console.WriteLine("Enter The Shape With The Corresponding Number");
            Console.WriteLine("Circle = 1");
            Console.WriteLine("Rectangle = 2");
            Console.WriteLine("Cylinder = 3");
           
            shape = int.Parse(Console.ReadLine());
            
            if (shape == 1)
            {
                Console.Clear();
                Console.WriteLine("Enter The Circle's Radius");
                areaOfCircle circleObject = new areaOfCircle();

                circleObject.circleRadiusInput = int.Parse(Console.ReadLine());
                
                Console.Clear();
                Console.WriteLine(circleObject.ToString());
                Console.Read();
            }
            else if (shape == 2)
            {
                Console.Clear();
                areaOfRectangle rectangleObject = new areaOfRectangle();
                Console.WriteLine("Enter The Rectangle's Length");
                rectangleObject.rectangleLengthInput = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter The Rectangle's Width");
                rectangleObject.rectangleWidthInput = int.Parse(Console.ReadLine());
               
                Console.Clear();
                Console.WriteLine(rectangleObject.ToString());
                Console.Read();
            }
            else //if(shape == 3)
            {
                Console.Clear();
                areaOfCylinder joe = new areaOfCylinder();
                
                areaOfCylinder cylinderObject = new areaOfCylinder();
                Console.WriteLine("Enter The Cylinder's Radius");
                cylinderObject.cylinderRadiusInput = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter The Cylinder's Height");
                cylinderObject.cylinderHeightInput = int.Parse(Console.ReadLine());


                Console.Clear();
                Console.WriteLine(cylinderObject.ToString());
                Console.Read();
            }

        





        
        }
   }
}
