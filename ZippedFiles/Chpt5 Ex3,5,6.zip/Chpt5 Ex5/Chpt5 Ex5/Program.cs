﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chpt5_Ex5
{
    class shippingCost
    {
        static void Main(string[] args)
        {   double total = getPurch();
            double rate = shipping(total);

            shipping(total);
            Displaythis(total, rate);
        }

        public static double getPurch()
        {   Console.WriteLine("Enter Total of the Purchases(s)");
            return int.Parse(Console.ReadLine());
        }

        public static double shipping (double totalPurch)
        {   double rate;
            
            //the calculations for total           

            if (totalPurch >= 5000.01)
            { rate = 20; }
            else if (totalPurch >= 1000.01)
            { rate = 15; }
            else if (totalPurch >= 500.01)
            { rate = 10; }
            else if (totalPurch >= 250.01)
            { rate = 8; }
            else
            { rate = 5; }

            string rateC = rate.ToString();

            return int.Parse(rateC);
        }


        public static void Displaythis(double total, double rate)
        { Console.WriteLine("Your Purchase = ${0}", total);
          Console.WriteLine("Your Shipping Cost = ${0}", rate);
        }



    }
}
