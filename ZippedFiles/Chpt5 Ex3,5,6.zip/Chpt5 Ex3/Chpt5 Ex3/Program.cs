﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chpt5
{
    class Program
    {
        static void Main(string[] args)
        {
            int answer1 = GetInput("first");
            int answer2 = GetInput("second");
            int answer3 = GetInput("third");
            int answer4 = GetInput("fourth");
            int answer5 = GetInput("fifth");
            string grade = Average(answer1, answer2, answer3, answer4, answer5);
            
            

            //Average(answer1, answer2, answer3, answer4, answer5,grade);
            Displaythis(answer1, answer2, answer3, answer4, answer5, grade);

        }

        public static int GetInput(string word)
        {   Console.WriteLine("Enter {0} Test Grade", word);            
            return int.Parse(Console.ReadLine());
        }

        public static string Average(int answer1, int answer2, int answer3, int answer4, int answer5)
        {
            double Aver;
            string grade;

            //the calculations for Average
            Aver= (answer1 + answer2 + answer3 + answer4 + answer5)/5;

            if (Aver >= 90)
            { grade = "You get an A"; }
            else if (Aver >= 80)
            { grade = "You get a B"; }
            else if (Aver >= 70)
            { grade = "You get a C"; }
            else if (Aver >= 60)
            { grade = "You get a D"; }
            else
            { grade = "You get an F and fall into quicksand and DIE!!! Please Try Again."; }

            return grade;
        
        }


        public static void Displaythis(int answer1, int answer2, int answer3, int answer4, int answer5, string grade)
        { Console.WriteLine("Your grades were {0},{1},{2},{3},{4} \nThe average is {5}", answer1, answer2 , answer3, answer4, answer5, grade); }



    }
}
