﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chpt7
{
    class Program
    {
        static void Main(string[] args)
        {
            string bigWord = "supercalifragilisticespialidocious";

            char[] brokenWord = bigWord.ToCharArray();

            for (int b = 0; b < brokenWord.Length; b++)
            {
                Console.WriteLine(brokenWord[b]);
            }    
            
            
            // [] makes it an array {{0}{1}{2}....}
            int[] first = {13,14,15,16,17,18};
            
            //this is the same, usual way to find the variables
            int[] second = new int[5];
            second[0] = 67;
            second[1] = 99;
            second[2] = 5;
            second[3] = 777;
            second[4] = 4444;
            
            Console.WriteLine("this is your number {0}      - {1}", first[3], second[2]);
            
            //another way to do arrays with user inputs
            int x = 5;
            int[] score = new int[x];

            ////another way
            string[] MyWord = { "where", "when", "how" };

            int[] MyRandom = new int[7];
            Random die = new Random();

            for (int j = 0; j < 100; j++)
            {
                int roll = die.Next(1, 7);
                MyRandom[roll]++;
            }
            for (int g = 0; g < MyRandom.Length; g++)
            {
                Console.WriteLine("there are {0} number {1}'s \n",MyRandom[g],g);
            }


            
            for (int count = 0; count < x; count++)
            {
                score[count] = scoreGetter();                   
            }

            Array.Sort(MyWord);

            foreach (string H in MyWord)
            {
                Console.WriteLine(H +"\n");
            }



            //for (int cnt = 0; cnt < x; cnt++)
            //{
            //    Console.WriteLine("your score is {0}\n",score[cnt]);  
            //}        
            
          }
        public static int scoreGetter()
        {
            Console.WriteLine("Enter your score");
            return int.Parse(Console.ReadLine());
        }

    }
}
