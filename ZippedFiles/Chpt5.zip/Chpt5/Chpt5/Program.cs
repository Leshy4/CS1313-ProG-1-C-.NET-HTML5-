﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chpt5
{
    class Program
    {   static void Main(string[] args)
        {   string answer = GetInput();
            string attack = "You find nothing";
            //for a text based game, get input, then consequences or triggers
            // && makes everything have to be true
            // || makes anything being true will run the program
            if (answer == "north" && attack == "You get attacked by indians, lose 50 life")
            { attack = "You find 500 gold"; }             
   
            else if(answer=="south")
            //you could nest if's so when you go into the quicksand
            // you could swim or relax
            {attack="You fall in quick sand and die"; }

            else if(answer=="west")
            { attack="Your wheel breaks and you lose two turns"; }

            else
            {attack = "You get attacked by indians, lose 50 life"; }

            //same thing as else if, but a little easier
            //switch (answer)
            //{ case "north": attack = "You die";
            //        break;
            //  case "south": attack = "You Live";
            //        break;
            //  default: attack = "no way";
            //        break; }

            Displaythis(answer,attack);   
        }

        public static string GetInput()
        {   Console.WriteLine("Enter a Direction");
            return Console.ReadLine();
        }

        public static void Displaythis(string picker, string a)
        { Console.WriteLine("You picked go {0} \n {1}", picker, a); }



    }
}
