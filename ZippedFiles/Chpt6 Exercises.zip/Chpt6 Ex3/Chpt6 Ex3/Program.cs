﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chpt6_Ex3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("How Many Grades Would You Like To Enter?");
            int gradesEntered = int.Parse(Console.ReadLine());            

            double runningTotal = 0;
            double count = 0;
            
           while (count < gradesEntered)
                {  
                    Console.WriteLine("Enter Your Grade");
                    double grade = int.Parse(Console.ReadLine());
                    runningTotal += grade;                  
                    Console.WriteLine("The Running Total of The Grades is " + runningTotal);
                    count++;
                    Console.WriteLine((gradesEntered - count) + " More Grades To Enter");
                    
                    //termination
                    if (grade >= 101)
                    {
                        runningTotal = 0;
                        gradesEntered = 0;
                        Console.WriteLine("Start Over & Try Again");
                    }
                    if (grade <= -1)
                    {
                        runningTotal = 0;
                        gradesEntered = 0;
                        Console.WriteLine("Start Over & Try Again");
                    }

                }
             
             double average = runningTotal / gradesEntered;
             Console.WriteLine("Your Grade Total is " + runningTotal);
             Console.WriteLine("Your Grade Average is " + average);
            

        }


    }
}
