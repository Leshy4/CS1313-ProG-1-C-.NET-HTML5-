﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Chpt6_Ex1
{
    class Program
    {
        static void Main(string[] args)
        {
            int smallest=1000; 
            int largest =0; 
            int even =0;
            int myNum;
            string result = "";
            
            Random num = new Random();
            for(int count=0; count<100; count++)
            {                
                myNum= num.Next(1001);
                if(smallest>myNum)
                  {smallest=myNum;}

                if(largest<myNum)
                  {largest=myNum;}

                if (myNum % 2 == 0)
                   {even++;}
                
                result += myNum + "\t";                
            }
            
            result += "\n the smallest number is "+smallest+ "\n the largest number is " + largest + "\n the range is " +(largest-smallest);
            result += "\n the number of even numbers is " + even;
            MessageBox.Show(result);


        }





    }
}
