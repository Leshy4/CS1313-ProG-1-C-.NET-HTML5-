﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chpt6_Ex6
{
    class Program
    {
        static void Main(string[] args)
        {         
            
            string myLetter ="" ;;
            string number;
            string FullNumber = "";
            string letterCollection="";

            for (int j = 1; j < 11; j++)
            {
                myLetter = lGetter(j);
                myLetter = myLetter.ToUpper();
                letterCollection += myLetter;
                number = numConverter(myLetter);
                FullNumber += number;
            }


            Displayer(myLetter, FullNumber, letterCollection);
        }


        static string lGetter(int count)
        {
            Console.WriteLine("Enter Your Letter");
            return Console.ReadLine();
        }


        static string numConverter(string Letter)
        {
            string n;
            switch (Letter)
            {
                case "A":
                case "B":
                case "C": n = "2";
                    break;
                case "D":
                case "E":
                case "F": n = "3";
                    break;
                case "G":
                case "H":
                case "I": n = "4";
                    break;
                case "J":
                case "K":
                case "L": n = "5";
                    break;
                case "M":
                case "N":
                case "O": n = "6";
                    break;
                case "P":
                case "Q":
                case "R":
                case "S": n = "7";
                    break;
                case "T":
                case "U":
                case "V": n = "8";
                    break;
                case "W":
                case "X":
                case "Y":
                case "Z": n = "9";
                    break;
                default: n = "That's not a Letter!!!";
                    break;
            }
            return n;
        }


        static void Displayer(string Letter, string n, string list)
        {
            Console.WriteLine("The Corresponding Number to {0} = {1} {2}", Letter, n, list);
        }


    }
}
