﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chpt3
{
    class Program
    {
        //static=modifier void=return main=name string[]=parameter
     static void Main(string[] args)
        {   string first, last, middle;
            int age;
            age=AgeGetter();

            
            first = NameGetter("first");
            last = NameGetter("last");
            middle = NameGetter("middle");
            
            Displayer(first,last,middle,age);          
            
     
     }

     public static string NameGetter(string aWord)
        {
          Console.WriteLine("enter your {0} name", aWord);
          return Console.ReadLine();
        }

     public static int AgeGetter()
        {
         //some math stuff
           return 21;
         }

      public static void Displayer(string fname, string lname, string mname, int a)
        {
          Console.WriteLine("My name is {0} {2} {1} \nI'm {3:C} years old", fname, lname, mname, a);
        }



    }
}
