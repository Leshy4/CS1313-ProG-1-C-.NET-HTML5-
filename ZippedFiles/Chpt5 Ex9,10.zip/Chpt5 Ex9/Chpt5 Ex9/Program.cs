﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chpt5_Ex9
{
    class Program
    {
        static void Main(string[] args)
        {   
            string hex = GetHex();
            string dec = DecConverter(hex);           
            DisplayNumber(hex,dec);
        }

        //Case Statements
        static string DecConverter(string hex)
        {   string d;
                switch(hex)
            {
                case "1": d = "1";
                    break;
                case "2": d = "2";
                    break;
                case "3": d = "3";
                    break;
                case "4": d = "4";
                    break;
                case "5": d = "5";
                    break;
                case "6": d = "6";
                    break;
                case "7": d = "7";
                    break;
                case "8": d = "8";
                    break;
                case "9": d = "9";
                    break;
                case "A": d = "10";
                    break;
                case "B": d = "11";
                    break;
                case "C": d = "12";
                    break;
                case "D": d = "13";
                    break;
                case "E": d = "14";
                    break;
                case "F": d = "15";
                    break;
                default: d = "What were you thinking!?";
                    break;
            }
            return d;
        }
        
        static string GetHex()
        { 
            Console.WriteLine("Enter Your Hex Value");
            return Console.ReadLine();
        }

        static void DisplayNumber(string hNum, string dNum)
        {                                       // "\n" = New Line
            Console.WriteLine("The Hex Number was {0} \n The Decimal Number was {1}", hNum, dNum);
        }







    }
}
