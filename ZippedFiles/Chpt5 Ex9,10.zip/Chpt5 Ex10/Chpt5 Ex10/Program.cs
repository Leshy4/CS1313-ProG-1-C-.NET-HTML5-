﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chpt5_Ex10
{
    class Program
    {
        static void Main(string[] args)
        {
            string letter = LGetter();
            //This Makes Capitalization irrelevant
            string myletter = letter.ToUpper();
            string number = numConverter(myletter);            

            Display(letter,number);
        }

        static string numConverter(string L)
        {
            string n;
                switch(L)
                {
                    case "A":
                    case "B":
                    case "C": n = "2";
                       break;
                    case "D":
                    case "E":
                    case "F": n = "3";
                       break;
                    case "G":
                    case "H":
                    case "I": n = "4";
                       break;
                    case "J":
                    case "K":
                    case "L": n = "5";
                       break;
                    case "M":
                    case "N":
                    case "O": n = "6";
                       break;
                    case "P":
                    case "Q":
                    case "R": 
                    case "S": n = "7";
                       break;
                    case "T":
                    case "U":
                    case "V": n = "8";
                       break;
                    case "W":
                    case "X":
                    case "Y":
                    case "Z": n = "9";
                       break;                   
                    default: n = "Not An Option";
                        break;
                }
            return n;
        }
        
        static string LGetter()
        {
            Console.WriteLine("please enter your letter");
            return Console.ReadLine();
        }

        static void Display(string l, string n)
        {
            Console.WriteLine("the letter you entered was {0} \nthe corresponding number is {1}",l,n);
            
        }








    }
}
