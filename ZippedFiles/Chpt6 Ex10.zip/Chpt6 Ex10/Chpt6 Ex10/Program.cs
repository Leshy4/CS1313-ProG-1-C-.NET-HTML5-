﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chpt6_Ex10
{
    class Program
    {
        static void Main(string[] args)
        {   
            Console.WriteLine("Enter A Number");
            int myNum = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter a character");
            char myChar = Convert.ToChar(Console.Read());
            
            int count = 0;

            for (int i = 0; i < myNum; i++)
            {
                while (count <= i)
                {
                    Console.Write(myChar);  
                    count++;
                }
                count = 0;
                Console.Write("\n");
            }
            for (int i = myNum; i > 0; i--)
            {
                while (count <= i)
                {
                    Console.Write(myChar);
                    count++;
                }
                count=0;
                Console.Write("\n");
            }
        }
    }
}