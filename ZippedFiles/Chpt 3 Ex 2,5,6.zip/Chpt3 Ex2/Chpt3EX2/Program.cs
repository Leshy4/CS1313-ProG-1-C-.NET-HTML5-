﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chpt3EX2
{
    class Program
    {
        static void Main(string[] args)
        {
            string blank;

            blank = qGetter("Please Enter Your Favorite Quote");
            Displayer(blank);
           
        }





        public static string qGetter(string Q)
        {

            Console.WriteLine("{0}",Q);
            return Console.ReadLine();
                
        }
        
  




        public static void Displayer(string Q)
        {

            Console.WriteLine("I like the saying *{0}*.", Q);
            Console.ReadLine(); 
        }
    }
}
