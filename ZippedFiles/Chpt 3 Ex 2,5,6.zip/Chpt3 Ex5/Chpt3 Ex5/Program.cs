﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chpt3_Ex5
{
    class Program
    {
        static void Main(string[] args)
        {
            int Cel;
            double Far;
            Cel = cGetter();
            
            
           
            Far = (Cel*1.8) + 32;

            Displayer(Cel, Far);

        }
        //user input for Celsuis
        static int cGetter()
        {
            Console.WriteLine("Celsius");
            return int.Parse(Console.ReadLine());
            
        }

        static void Displayer(int C, double F)
        {
            Console.WriteLine("{0} Celsius is equal to {1} Farenheit", C, F);
        }


    }
}
