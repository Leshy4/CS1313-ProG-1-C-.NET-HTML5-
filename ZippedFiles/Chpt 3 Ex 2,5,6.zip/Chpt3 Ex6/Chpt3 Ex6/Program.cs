﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chpt2_Ex7
{
    class Program
    {
        static void Main(string[] args)
        {
            //int DOLLAR = 100;
            //DOLLAR>COIN;

            int COIN=cGetter();                       
            int QUARTER;
            int DIME;
            int NICKLE;
            int PENNY;

            //COIN < 100;
            

          

            QUARTER=qGetter(COIN);
            DIME=dGetter(COIN, QUARTER);
            NICKLE=nGetter(COIN, QUARTER, DIME);
            PENNY=pGetter(COIN,QUARTER,DIME,NICKLE);
            Displayer(COIN,QUARTER, DIME, NICKLE, PENNY);
        }
        //Allows Coin input for user
        public static int cGetter()
        {
            
            Console.WriteLine("Please Enter Amount of Change");
            
            return int.Parse(Console.ReadLine());
        }
        
        //qGetter is for Quarters
        public static int qGetter(int C)
        {
            double Q;
            Q= C / 25;
            //converts ints to strings
            string Q1 = Q.ToString();
            return int.Parse(Q1); 
        }
        //dGetter is for Dimes
        public static int dGetter(int C, int Q)
        {
            double D;
            D = (C - Q * 25) / 10;
       
            string D1 = D.ToString();
            return int.Parse(D1);
        }
        //nGetter is for Nickles
        public static int nGetter(int C, int Q, int D)
        {
            double N;
            N= ((C - Q * 25) - (D * 10)) / 5;
            string N1 = N.ToString();
            return int.Parse(N1);
        }
        //pGetter is for Pennies
        public static int pGetter(int C, int Q, int D, int N)
        {
            double P;
            P = C- (Q * 25) - (D * 10) - (N * 5);
            string P1 = P.ToString();
            return int.Parse(P1);
        }

        //Displays the result
        public static void Displayer(int c, int q, int d, int n, int p)
        {

            Console.WriteLine("If I have {0} in change I need {1} Quarters, {2} Dimes, {3} Nickles, and {4} Pennies", c, q, d, n, p);

        }


    }
}
